chrome.runtime.onInstalled.addListener(async () => {
  const { trustedDomains } = await chrome.storage.sync.get('trustedDomains');
  if (!trustedDomains) {
    await chrome.storage.sync.set({
      trustedDomains: [
        'amazon.com', 'ebay.com', 'etsy.com',
        'walmart.com', 'target.com', 'bestbuy.com',
        'shopify.com', 'nike.com', 'macys.com'
      ]
    });
  }

  const { settings } = await chrome.storage.sync.get('settings');
  if (!settings) {
    await chrome.storage.sync.set({
      settings: {
        autoApply: true,
        notifications: true,
        theme: 'light',
        source: 'auto'
      }
    });
  }

  chrome.alarms.create('cleanup', { periodInMinutes: 1440 });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'cleanup') {
    const { history } = await chrome.storage.local.get('history');
    if (history && Array.isArray(history)) {
      const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
      const filtered = history.filter(h => h.timestamp > thirtyDaysAgo);
      await chrome.storage.local.set({ history: filtered });
    }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'fetchCoupons':
      fetchCoupons(message.domain, sendResponse);
      return true;
    case 'applyCoupon':
      applyCoupon(message.code, message.tabId, sendResponse);
      return true;
    case 'notify':
      if (message.type === 'success') {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: '/icons/icon48.png',
          title: 'AutoCoupon',
          message: message.text
        });
      }
      sendResponse({ ok: true });
      return true;
  }
});

async function fetchCoupons(domain, sendResponse) {
  try {
    const { couponCache } = await chrome.storage.local.get('couponCache');
    const cache = couponCache || {};
    const cached = cache[domain];

    if (cached && cached.expires > Date.now()) {
      sendResponse({ ok: true, coupons: cached.codes, fromCache: true });
      return;
    }

    const coupons = await scrapeCouponSources(domain);
    if (coupons && coupons.length > 0) {
      cache[domain] = {
        codes: coupons,
        expires: Date.now() + 6 * 60 * 60 * 1000
      };
      await chrome.storage.local.set({ couponCache: cache });
    }

    sendResponse({ ok: true, coupons: coupons || [], fromCache: false });
  } catch (err) {
    sendResponse({ ok: false, error: err.message });
  }
}

const COUPON_DB = {
  'amazon.com': [
    { code: 'SAVE10', discount: '10% zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas' },
    { code: 'AMZ5OFF', discount: '$5 zbritje' }
  ],
  'ebay.com': [
    { code: 'EBAY20', discount: '20% zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas' },
    { code: 'SAVE15', discount: '15% zbritje' }
  ],
  'etsy.com': [
    { code: 'ETSY10', discount: '10% zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas mbi $35' },
    { code: 'WELCOME5', discount: '$5 zbritje për porosi të parë' }
  ],
  'walmart.com': [
    { code: 'WALMART5', discount: '$5 zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas' },
    { code: 'SAVEMORE', discount: '10% zbritje' }
  ],
  'target.com': [
    { code: 'TARGET10', discount: '10% zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas' },
    { code: 'CIRCLE5', discount: '$5 zbritje me Target Circle' }
  ],
  'bestbuy.com': [
    { code: 'BBYSAVE', discount: '10% zbritje në aksesorë' },
    { code: 'FREESHIP', discount: 'Transport falas' }
  ],
  'nike.com': [
    { code: 'NIKE10', discount: '10% zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas' },
    { code: 'MEMBER15', discount: '15% për anëtarë' }
  ],
  'macys.com': [
    { code: 'MACYS20', discount: '20% zbritje' },
    { code: 'FREESHIP', discount: 'Transport falas mbi $49' },
    { code: 'SAVE25', discount: '25% zbritje në shtëpi' }
  ],
  'shopify.com': [
    { code: 'SHOPIFY10', discount: '10% zbritje' },
    { code: 'WELCOME', discount: 'Zbritje për klientë të rinj' }
  ]
};

async function scrapeCouponSources(domain) {
  const baseDomain = domain.replace(/^www\./, '');
  const cleanDomain = baseDomain.split('/')[0];

  const fromDb = COUPON_DB[cleanDomain] || COUPON_DB[Object.keys(COUPON_DB).find(k => cleanDomain.includes(k))];
  if (fromDb) return [...fromDb];

  return [];
}

async function applyCoupon(code, tabId, sendResponse) {
  try {
    await chrome.tabs.sendMessage(tabId, { action: 'applyCoupon', code });
    sendResponse({ ok: true });
  } catch (err) {
    sendResponse({ ok: false, error: err.message });
  }
}
