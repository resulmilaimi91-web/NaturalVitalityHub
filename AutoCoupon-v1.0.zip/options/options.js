let settings = {};
let blacklist = [];
let trustedDomains = [];

document.addEventListener('DOMContentLoaded', async () => {
  await loadAll();
  bindEvents();
});

async function loadAll() {
  const sync = await chrome.storage.sync.get(['settings', 'blacklist', 'trustedDomains']);
  settings = sync.settings || { autoApply: true, notifications: true, theme: 'light', source: 'auto' };
  blacklist = sync.blacklist || [];
  trustedDomains = sync.trustedDomains || [];

  const autoSwitch = document.getElementById('autoApplySwitch');
  const notifSwitch = document.getElementById('notifSwitch');

  autoSwitch.classList.toggle('on', settings.autoApply);
  notifSwitch.classList.toggle('on', settings.notifications);

  document.getElementById('themeSelect').value = settings.theme || 'light';
  document.getElementById('sourceSelect').value = settings.source || 'auto';

  renderTags('blacklistTags', blacklist, 'blacklist');
  renderTags('trustedTags', trustedDomains, 'trusted');
}

function renderTags(containerId, items, type) {
  const container = document.getElementById(containerId);
  container.innerHTML = items.map(item => `
    <span class="tag">
      ${item}
      <span class="remove" data-item="${item}" data-type="${type}">&times;</span>
    </span>
  `).join('');

  container.querySelectorAll('.remove').forEach(el => {
    el.addEventListener('click', async () => {
      const item = el.dataset.item;
      const list = type === 'blacklist' ? blacklist : trustedDomains;
      const idx = list.indexOf(item);
      if (idx > -1) list.splice(idx, 1);
      if (type === 'blacklist') {
        await chrome.storage.sync.set({ blacklist: list });
      } else {
        await chrome.storage.sync.set({ trustedDomains: list });
      }
      renderTags(containerId, list, type);
    });
  });
}

function bindEvents() {
  document.getElementById('autoApplySwitch').addEventListener('click', function () {
    this.classList.toggle('on');
    settings.autoApply = this.classList.contains('on');
  });

  document.getElementById('notifSwitch').addEventListener('click', function () {
    this.classList.toggle('on');
    settings.notifications = this.classList.contains('on');
  });

  document.getElementById('themeSelect').addEventListener('change', function () {
    settings.theme = this.value;
  });

  document.getElementById('sourceSelect').addEventListener('change', function () {
    settings.source = this.value;
  });

  document.getElementById('addBlacklistBtn').addEventListener('click', async () => {
    const input = document.getElementById('blacklistInput');
    const domain = input.value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (domain && !blacklist.includes(domain)) {
      blacklist.push(domain);
      await chrome.storage.sync.set({ blacklist });
      renderTags('blacklistTags', blacklist, 'blacklist');
      input.value = '';
    }
  });

  document.getElementById('addTrustedBtn').addEventListener('click', async () => {
    const input = document.getElementById('trustedInput');
    const domain = input.value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    if (domain && !trustedDomains.includes(domain)) {
      trustedDomains.push(domain);
      await chrome.storage.sync.set({ trustedDomains });
      renderTags('trustedTags', trustedDomains, 'trusted');
      input.value = '';
    }
  });

  ['blacklistInput', 'trustedInput'].forEach(id => {
    document.getElementById(id).addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const btn = id === 'blacklistInput' ? 'addBlacklistBtn' : 'addTrustedBtn';
        document.getElementById(btn).click();
      }
    });
  });

  document.getElementById('saveBtn').addEventListener('click', async () => {
    await chrome.storage.sync.set({ settings });
    const toast = document.getElementById('toast');
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2000);
  });

  document.getElementById('exportBtn').addEventListener('click', async () => {
    const sync = await chrome.storage.sync.get(null);
    const local = await chrome.storage.local.get(null);
    const blob = new Blob([JSON.stringify({ sync, local, exportedAt: new Date().toISOString() }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'autocoupon-backup.json';
    a.click();
    URL.revokeObjectURL(url);
  });

  document.getElementById('importBtn').addEventListener('click', async () => {
    const text = document.getElementById('importText').value.trim();
    if (!text) return;
    try {
      const data = JSON.parse(text);
      if (data.sync) await chrome.storage.sync.set(data.sync);
      if (data.local) await chrome.storage.local.set(data.local);
      document.getElementById('importText').value = '';
      document.getElementById('toast').textContent = 'Importimi u krye me sukses!';
      document.getElementById('toast').classList.add('show');
      setTimeout(() => {
        document.getElementById('toast').classList.remove('show');
        document.getElementById('toast').textContent = 'Opsionet u ruajtën!';
      }, 2000);
      await loadAll();
    } catch {
      alert('JSON i pavlefshëm. Kontrollo formatin.');
    }
  });

  document.getElementById('resetAllBtn').addEventListener('click', async () => {
    if (confirm('Kjo do të fshijë të gjitha të dhënat. Vazhdo?')) {
      if (confirm('Je i sigurt? Nuk mund të kthehet mbrapa.')) {
        await chrome.storage.sync.clear();
        await chrome.storage.local.clear();
        await loadAll();
        document.getElementById('toast').textContent = 'Të dhënat u rivendosën!';
        document.getElementById('toast').classList.add('show');
        setTimeout(() => {
          document.getElementById('toast').classList.remove('show');
          document.getElementById('toast').textContent = 'Opsionet u ruajtën!';
        }, 2000);
      }
    }
  });
}
