const AutoCouponStorage = {
  async getSettings() {
    const { settings } = await chrome.storage.sync.get('settings');
    return settings || { autoApply: true, notifications: true, theme: 'light', source: 'auto' };
  },

  async saveSettings(settings) {
    await chrome.storage.sync.set({ settings });
  },

  async getTrustedDomains() {
    const { trustedDomains } = await chrome.storage.sync.get('trustedDomains');
    return trustedDomains || [];
  },

  async addTrustedDomain(domain) {
    const domains = await this.getTrustedDomains();
    if (!domains.includes(domain)) {
      domains.push(domain);
      await chrome.storage.sync.set({ trustedDomains: domains });
    }
    return domains;
  },

  async removeTrustedDomain(domain) {
    let domains = await this.getTrustedDomains();
    domains = domains.filter(d => d !== domain);
    await chrome.storage.sync.set({ trustedDomains: domains });
    return domains;
  },

  async getBlacklist() {
    const { blacklist } = await chrome.storage.sync.get('blacklist');
    return blacklist || [];
  },

  async addToBlacklist(domain) {
    const blacklist = await this.getBlacklist();
    if (!blacklist.includes(domain)) {
      blacklist.push(domain);
      await chrome.storage.sync.set({ blacklist });
    }
    return blacklist;
  },

  async removeFromBlacklist(domain) {
    let blacklist = await this.getBlacklist();
    blacklist = blacklist.filter(d => d !== domain);
    await chrome.storage.sync.set({ blacklist });
    return blacklist;
  },

  async getHistory() {
    const { history } = await chrome.storage.local.get('history');
    return history || [];
  },

  async addToHistory(entry) {
    const { history } = await chrome.storage.local.get('history');
    const list = history || [];
    list.unshift({
      ...entry,
      timestamp: Date.now(),
      id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
    });
    if (list.length > 200) list.length = 200;
    await chrome.storage.local.set({ history: list });
    return list;
  },

  async clearHistory() {
    await chrome.storage.local.set({ history: [] });
  },

  async getCouponCache() {
    const { couponCache } = await chrome.storage.local.get('couponCache');
    return couponCache || {};
  },

  async setCouponCache(domain, coupons) {
    const cache = await this.getCouponCache();
    cache[domain] = {
      codes: coupons,
      expires: Date.now() + 6 * 60 * 60 * 1000
    };
    await chrome.storage.local.set({ couponCache: cache });
  },

  async exportData() {
    const sync = await chrome.storage.sync.get(null);
    const local = await chrome.storage.local.get(null);
    return JSON.stringify({ sync, local, exportedAt: new Date().toISOString() }, null, 2);
  },

  async importData(json) {
    try {
      const data = JSON.parse(json);
      if (data.sync) await chrome.storage.sync.set(data.sync);
      if (data.local) await chrome.storage.local.set(data.local);
      return true;
    } catch {
      return false;
    }
  },

  async resetAll() {
    await chrome.storage.sync.clear();
    await chrome.storage.local.clear();
  },

  async saveStep(stepIndex) {
    const { planProgress } = await chrome.storage.local.get('planProgress');
    const progress = planProgress || [];
    if (!progress.includes(stepIndex)) {
      progress.push(stepIndex);
      await chrome.storage.local.set({ planProgress: progress });
    }
    return progress;
  },

  async getPlanProgress() {
    const { planProgress } = await chrome.storage.local.get('planProgress');
    return planProgress || [];
  },

  async resetPlanProgress() {
    await chrome.storage.local.set({ planProgress: [] });
  }
};
