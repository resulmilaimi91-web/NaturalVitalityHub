let currentCoupons = [];

document.addEventListener('DOMContentLoaded', () => {
  const scanBtn = document.getElementById('scanBtn');
  const autoApplyBtn = document.getElementById('autoApplyBtn');
  const searchInput = document.getElementById('searchInput');
  const statusText = document.getElementById('statusText');
  const statusBar = document.getElementById('statusBar');
  const couponList = document.getElementById('couponList');
  const emptyState = document.getElementById('emptyState');
  const countBadge = document.getElementById('countBadge');
  const historyBtn = document.getElementById('historyBtn');
  const optionsBtn = document.getElementById('optionsBtn');
  const historyPanel = document.getElementById('historyPanel');
  const historyBack = document.getElementById('historyBack');
  const historyList = document.getElementById('historyList');
  const clearHistoryBtn = document.getElementById('clearHistory');

  scanBtn.addEventListener('click', scanCoupons);
  autoApplyBtn.addEventListener('click', autoApply);
  historyBtn.addEventListener('click', showHistory);
  optionsBtn.addEventListener('click', () => chrome.runtime.openOptionsPage());
  historyBack.addEventListener('click', () => historyPanel.classList.add('hidden'));
  clearHistoryBtn.addEventListener('click', clearHistory);

  searchInput.addEventListener('input', (e) => {
    const q = e.target.value.toLowerCase();
    renderCoupons(currentCoupons.filter(c => c.code.toLowerCase().includes(q) || (c.discount || '').toLowerCase().includes(q)));
  });

  function scanCoupons() {
    setStatus('loading', 'Duke kërkuar kupona...');
    scanBtn.disabled = true;
    scanBtn.textContent = 'Duke kërkuar...';

    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab) {
        setStatus('idle', 'Nuk u gjet faqja');
        resetBtn();
        return;
      }

      const domain = new URL(tab.url).hostname.replace('www.', '');
      let allCoupons = [];
      let fromPage = false;

      try {
        const response = await chrome.runtime.sendMessage({ action: 'fetchCoupons', domain });
        if (response && response.ok && response.coupons) {
          allCoupons = response.coupons;
        }
      } catch {}

      try {
        const pageScan = await chrome.tabs.sendMessage(tab.id, { action: 'scanPage' });
        if (pageScan && pageScan.ok && pageScan.coupons) {
          const seenCodes = new Set(allCoupons.map(c => c.code));
          for (const c of pageScan.coupons) {
            if (!seenCodes.has(c.code)) {
              allCoupons.push(c);
              seenCodes.add(c.code);
              fromPage = true;
            }
          }
        }
      } catch {}

      resetBtn();
      if (allCoupons.length > 0) {
        currentCoupons = allCoupons;
        renderCoupons(currentCoupons);
        countBadge.textContent = currentCoupons.length;
        emptyState.classList.remove('show');
        setStatus('idle', `${currentCoupons.length} kupona u gjetën${fromPage ? ' (disa nga faqja)' : ''}`);
      } else {
        currentCoupons = [];
        couponList.innerHTML = '';
        countBadge.textContent = '0';
        emptyState.classList.add('show');
        setStatus('idle', 'Asnjë kupon në këtë faqe');
      }
    });
  }

  function renderCoupons(coupons) {
    couponList.innerHTML = '';
    if (coupons.length === 0) {
      emptyState.classList.add('show');
      countBadge.textContent = '0';
      return;
    }
    emptyState.classList.remove('show');
    countBadge.textContent = coupons.length;

    coupons.forEach((c, i) => {
      const item = document.createElement('div');
      item.className = 'coupon-item';
      item.innerHTML = `
        <span class="code">${c.code}</span>
        <span class="discount">${c.discount || '&nbsp;'}</span>
        <span class="copy-icon">&#128203;</span>
      `;
      item.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(c.code);
          item.classList.add('copied');
          const codeEl = item.querySelector('.code');
          codeEl.textContent = 'U kopjua!';
          setTimeout(() => {
            item.classList.remove('copied');
            codeEl.textContent = c.code;
          }, 1500);
        } catch {}
      });
      couponList.appendChild(item);
    });
  }

  function autoApply() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];
      if (!tab) return;
      chrome.runtime.sendMessage(
        { action: 'fetchCoupons', domain: new URL(tab.url).hostname.replace('www.', '') },
        (response) => {
          if (!response || !response.ok || !response.coupons || response.coupons.length === 0) {
            setStatus('idle', 'Nuk u gjetën kupona për auto-apply');
            return;
          }
          chrome.runtime.sendMessage(
            { action: 'applyCoupon', code: response.coupons[0].code, tabId: tab.id },
            () => setStatus('idle', `Kodi ${response.coupons[0].code} u aplikua!`)
          );
        }
      );
    });
  }

  function showHistory() {
    chrome.storage.local.get('history', (result) => {
      const history = result.history || [];
      historyList.innerHTML = '';
      if (history.length === 0) {
        historyList.innerHTML = '<div style="text-align:center;padding:40px 0;color:var(--text-dim);font-size:.8rem">Asnjë histori</div>';
      } else {
        history.slice(0, 50).forEach(h => {
          const div = document.createElement('div');
          div.className = 'history-item';
          const time = new Date(h.timestamp).toLocaleString('sq-AL');
          div.innerHTML = `
            <div><span class="h-domain">${h.domain}</span> &rarr; <span class="h-code">${h.code}</span></div>
            ${h.discount ? `<div style="font-size:.72rem;color:var(--text-dim)">${h.discount}</div>` : ''}
            <div class="h-time">${time}</div>
          `;
          historyList.appendChild(div);
        });
      }
      historyPanel.classList.remove('hidden');
    });
  }

  function clearHistory() {
    if (confirm('Pastro historikun e kuponave?')) {
      chrome.storage.local.set({ history: [] }, () => {
        historyList.innerHTML = '<div style="text-align:center;padding:40px 0;color:var(--text-dim);font-size:.8rem">Histori e pastruar</div>';
      });
    }
  }

  function setStatus(type, text) {
    statusBar.className = 'status ' + type;
    statusText.textContent = text;
  }

  function resetBtn() {
    scanBtn.disabled = false;
    scanBtn.textContent = 'Kërko Kupona';
  }
});
