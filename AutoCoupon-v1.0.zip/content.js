(function () {
  let currentDomain = window.location.hostname.replace('www.', '');
  let appliedCodes = new Set();

  init();

  async function init() {
    try {
      const result = await chrome.storage.sync.get(['blacklist', 'settings']);
      const blacklist = result.blacklist || [];
      if (blacklist.some(d => currentDomain.includes(d))) return;

      const settings = result.settings || { autoApply: true, notifications: true };
      window.__autoCouponSettings = settings;

      if (settings.autoApply) {
        setTimeout(findAndApplyCoupon, 800);
      }
    } catch {}
  }

  function findCouponFields() {
    const selectors = [
      'input[placeholder*="coupon" i]',
      'input[placeholder*="promo" i]',
      'input[placeholder*="discount" i]',
      'input[placeholder*="code" i]',
      'input[aria-label*="coupon" i]',
      'input[aria-label*="promo" i]',
      'input[name*="coupon" i]',
      'input[name*="promo" i]',
      'input[id*="coupon" i]',
      'input[id*="promo" i]',
      '.promo-code input',
      '.coupon-code input',
      '.discount-code input',
      '[data-testid*="coupon" i] input',
      '[class*="coupon" i] input',
      '[class*="promo" i] input'
    ];

    for (const sel of selectors) {
      const fields = document.querySelectorAll(sel);
      if (fields.length > 0) return fields[0];
    }
    return null;
  }

  function findApplyButton() {
    const selectors = [
      'button[type="submit"]',
      '[class*="apply" i] button',
      'button[class*="apply" i]',
      '[data-testid*="apply" i]',
      'button'
    ];

    const keywords = ['apply', 'applied', 'applikoj', 'aplikoj', 'përdor', 'redeem', 'submit', 'vazhdo'];

    for (const sel of selectors) {
      const btns = document.querySelectorAll(sel);
      for (const btn of btns) {
        const text = btn.textContent.toLowerCase().trim();
        if (keywords.some(k => text.includes(k))) {
          return btn;
        }
      }
    }

    for (const btn of document.querySelectorAll('button')) {
      if (btn.offsetParent !== null) {
        const text = btn.textContent.toLowerCase().trim();
        if (keywords.some(k => text.includes(k))) {
          return btn;
        }
      }
    }
    return null;
  }

  async function findAndApplyCoupon() {
    const field = findCouponFields();
    if (!field) return;

    try {
      const response = await chrome.runtime.sendMessage(
        { action: 'fetchCoupons', domain: currentDomain }
      );

      if (!response || !response.ok || !response.coupons || response.coupons.length === 0) return;

      for (const coupon of response.coupons) {
        if (!coupon.code || appliedCodes.has(coupon.code)) continue;

        field.value = coupon.code;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));

        await new Promise(r => setTimeout(r, 400));

        const applyBtn = findApplyButton();
        if (applyBtn) {
          applyBtn.click();
          appliedCodes.add(coupon.code);
          showNotification(coupon);
          logSuccess(coupon);
          break;
        }
      }
    } catch {}
  }

  function showNotification(coupon) {
    const existing = document.querySelector('.autocoupon-notif');
    if (existing) existing.remove();

    const notif = document.createElement('div');
    notif.className = 'autocoupon-notif';
    notif.style.cssText = `
      position: fixed; top: 16px; right: 16px; z-index: 2147483647;
      background: #10b981; color: #fff; padding: 12px 20px;
      border-radius: 10px; font-family: system-ui, sans-serif;
      font-size: 14px; box-shadow: 0 8px 24px rgba(0,0,0,.15);
      max-width: 340px; animation: slideIn .3s ease; cursor: pointer;
    `;
    notif.innerHTML = `
      <div style="font-weight:700;margin-bottom:2px">AutoCoupon</div>
      <div>Kodi <strong>${coupon.code}</strong> u aplikua!</div>
      ${coupon.discount ? `<div style="font-size:12px;opacity:.9;margin-top:3px">${coupon.discount}</div>` : ''}
    `;
    notif.onclick = () => notif.remove();

    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn { from { opacity:0; transform:translateX(40px); } to { opacity:1; transform:translateX(0); } }
      .autocoupon-notif:hover { opacity:.95; }
    `;
    document.head.appendChild(style);
    document.body.appendChild(notif);

    setTimeout(() => {
      notif.style.transition = 'opacity .3s, transform .3s';
      notif.style.opacity = '0';
      notif.style.transform = 'translateX(40px)';
      setTimeout(() => notif.remove(), 400);
    }, 5000);
  }

  function logSuccess(coupon) {
    chrome.storage.local.get('history', (result) => {
      const history = result.history || [];
      history.unshift({
        domain: currentDomain,
        code: coupon.code,
        discount: coupon.discount || '',
        timestamp: Date.now(),
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6)
      });
      if (history.length > 200) history.length = 200;
      chrome.storage.local.set({ history });
    });
  }

  function scanPageForCoupons() {
    const found = [];
    const seen = new Set();

    const patterns = [
      /[A-Z0-9]{4,20}/g
    ];

    const couponKeywords = ['coupon', 'kupon', 'promo', 'discount', 'zbritje', 'code', 'save', 'kursen'];

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent.trim();
      if (text.length < 3 || text.length > 30) continue;
      if (!couponKeywords.some(k => node.parentElement?.textContent?.toLowerCase().includes(k))) continue;

      for (const pattern of patterns) {
        const matches = text.match(pattern);
        if (matches) {
          for (const m of matches) {
            if (m.length >= 4 && !seen.has(m)) {
              seen.add(m);
              let discount = '';
              const parentText = node.parentElement?.textContent || '';
              const discMatch = parentText.match(/(\d+)\s*%|%\s*(\d+)|(\d+)\s*dollar|\$\s*(\d+)/i);
              if (discMatch) {
                discount = discMatch[0];
              }
              found.push({ code: m, discount });
            }
          }
        }
      }
    }

    return found;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'applyCoupon') {
      const field = findCouponFields();
      if (field) {
        field.value = message.code;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
        setTimeout(() => {
          const btn = findApplyButton();
          if (btn) btn.click();
        }, 300);
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: 'Nuk u gjet fushë kuponi' });
      }
      return true;
    }

    if (message.action === 'scanPage') {
      sendResponse({ ok: true, coupons: scanPageForCoupons() });
      return true;
    }

    if (message.action === 'ping') {
      sendResponse({ ok: true, domain: currentDomain });
      return true;
    }
  });
})();
