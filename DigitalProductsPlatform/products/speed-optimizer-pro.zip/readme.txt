=== Speed Optimizer Pro ===
Contributors: speedmaster
Tags: speed, cache, performance, wordpress
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 3.5.0
License: GPL v2 or later

Supercharge your WordPress with page caching, image optimization, minification, CDN, and lazy load.